
package net.mcreator.senseichazmasters.potion;

import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.effect.MobEffectCategory;
import net.minecraft.world.effect.InstantenousMobEffect;

import net.mcreator.senseichazmasters.procedures.RainingArrowsEffectStartedappliedProcedure;

public class RainingArrowsMobEffect extends InstantenousMobEffect {
	public RainingArrowsMobEffect() {
		super(MobEffectCategory.HARMFUL, -4756643);
	}

	@Override
	public void applyInstantenousEffect(Entity source, Entity indirectSource, LivingEntity entity, int amplifier, double health) {
		RainingArrowsEffectStartedappliedProcedure.execute(entity.level(), entity);
	}

	@Override
	public boolean shouldApplyEffectTickThisTick(int duration, int amplifier) {
		return true;
	}

	@Override
	public boolean applyEffectTick(LivingEntity entity, int amplifier) {
		RainingArrowsEffectStartedappliedProcedure.execute(entity.level(), entity);
		return super.applyEffectTick(entity, amplifier);
	}
}
