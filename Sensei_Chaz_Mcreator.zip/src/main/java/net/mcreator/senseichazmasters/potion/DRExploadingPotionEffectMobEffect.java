
package net.mcreator.senseichazmasters.potion;

import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.effect.MobEffectCategory;
import net.minecraft.world.effect.InstantenousMobEffect;

import net.mcreator.senseichazmasters.procedures.DRExploadingPotionEffectEffectStartedappliedProcedure;

public class DRExploadingPotionEffectMobEffect extends InstantenousMobEffect {
	public DRExploadingPotionEffectMobEffect() {
		super(MobEffectCategory.HARMFUL, -65485);
	}

	@Override
	public void applyInstantenousEffect(Entity source, Entity indirectSource, LivingEntity entity, int amplifier, double health) {
		DRExploadingPotionEffectEffectStartedappliedProcedure.execute(entity.level(), entity);
	}
}
