
package net.mcreator.senseichazmasters.potion;

import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.effect.MobEffectCategory;
import net.minecraft.world.effect.MobEffect;

import net.mcreator.senseichazmasters.procedures.DrRainArrowEffectStartedappliedProcedure;

public class DrRainArrowMobEffect extends MobEffect {
	public DrRainArrowMobEffect() {
		super(MobEffectCategory.HARMFUL, -16738048);
	}

	@Override
	public void onEffectStarted(LivingEntity entity, int amplifier) {
		DrRainArrowEffectStartedappliedProcedure.execute(entity.level(), entity);
	}

	@Override
	public boolean shouldApplyEffectTickThisTick(int duration, int amplifier) {
		return true;
	}

	@Override
	public boolean applyEffectTick(LivingEntity entity, int amplifier) {
		DrRainArrowEffectStartedappliedProcedure.execute(entity.level(), entity);
		return super.applyEffectTick(entity, amplifier);
	}
}
