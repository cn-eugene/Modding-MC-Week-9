
/*
 *	MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.senseichazmasters.init;

import net.neoforged.neoforge.registries.DeferredRegister;
import net.neoforged.neoforge.registries.DeferredHolder;

import net.minecraft.world.effect.MobEffect;
import net.minecraft.core.registries.Registries;

import net.mcreator.senseichazmasters.potion.RainingArrowsMobEffect;
import net.mcreator.senseichazmasters.potion.ExploadingPotionMobEffect;
import net.mcreator.senseichazmasters.potion.DrRainArrowMobEffect;
import net.mcreator.senseichazmasters.potion.DRExploadingPotionEffectMobEffect;
import net.mcreator.senseichazmasters.SenseichazmastersMod;

public class SenseichazmastersModMobEffects {
	public static final DeferredRegister<MobEffect> REGISTRY = DeferredRegister.create(Registries.MOB_EFFECT, SenseichazmastersMod.MODID);
	public static final DeferredHolder<MobEffect, MobEffect> EXPLOADING_POTION = REGISTRY.register("exploading_potion", () -> new ExploadingPotionMobEffect());
	public static final DeferredHolder<MobEffect, MobEffect> RAINING_ARROWS = REGISTRY.register("raining_arrows", () -> new RainingArrowsMobEffect());
	public static final DeferredHolder<MobEffect, MobEffect> DR_EXPLOADING_POTION_EFFECT = REGISTRY.register("dr_exploading_potion_effect", () -> new DRExploadingPotionEffectMobEffect());
	public static final DeferredHolder<MobEffect, MobEffect> DR_RAIN_ARROW = REGISTRY.register("dr_rain_arrow", () -> new DrRainArrowMobEffect());
}
