
/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.senseichazmasters.init;

import net.neoforged.neoforge.registries.DeferredRegister;
import net.neoforged.neoforge.registries.DeferredHolder;
import net.neoforged.neoforge.event.entity.SpawnPlacementRegisterEvent;
import net.neoforged.neoforge.event.entity.EntityAttributeCreationEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.bus.api.SubscribeEvent;

import net.minecraft.world.entity.MobCategory;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.Entity;
import net.minecraft.core.registries.Registries;

import net.mcreator.senseichazmasters.entity.StarChickenEntityProjectile;
import net.mcreator.senseichazmasters.entity.StarChickenEntity;
import net.mcreator.senseichazmasters.entity.SenseiEntityProjectile;
import net.mcreator.senseichazmasters.entity.SenseiEntity;
import net.mcreator.senseichazmasters.entity.PopProjectEntity;
import net.mcreator.senseichazmasters.entity.PopModEntityProjectile;
import net.mcreator.senseichazmasters.entity.PopModEntity;
import net.mcreator.senseichazmasters.entity.PopCatEntity;
import net.mcreator.senseichazmasters.entity.PROJECTILEEntity;
import net.mcreator.senseichazmasters.entity.ChazRanged2Entity;
import net.mcreator.senseichazmasters.SenseichazmastersMod;

@EventBusSubscriber(bus = EventBusSubscriber.Bus.MOD)
public class SenseichazmastersModEntities {
	public static final DeferredRegister<EntityType<?>> REGISTRY = DeferredRegister.create(Registries.ENTITY_TYPE, SenseichazmastersMod.MODID);
	public static final DeferredHolder<EntityType<?>, EntityType<StarChickenEntity>> STAR_CHICKEN = register("star_chicken",
			EntityType.Builder.<StarChickenEntity>of(StarChickenEntity::new, MobCategory.CREATURE).setShouldReceiveVelocityUpdates(true).setTrackingRange(64).setUpdateInterval(3)

					.sized(0.4f, 0.7f));
	public static final DeferredHolder<EntityType<?>, EntityType<StarChickenEntityProjectile>> STAR_CHICKEN_PROJECTILE = register("projectile_star_chicken",
			EntityType.Builder.<StarChickenEntityProjectile>of(StarChickenEntityProjectile::new, MobCategory.MISC).setShouldReceiveVelocityUpdates(true).setTrackingRange(64).setUpdateInterval(1).sized(0.5f, 0.5f));
	public static final DeferredHolder<EntityType<?>, EntityType<PROJECTILEEntity>> PROJECTILE = register("projectile",
			EntityType.Builder.<PROJECTILEEntity>of(PROJECTILEEntity::new, MobCategory.MISC).setShouldReceiveVelocityUpdates(true).setTrackingRange(64).setUpdateInterval(1).sized(0.5f, 0.5f));
	public static final DeferredHolder<EntityType<?>, EntityType<ChazRanged2Entity>> CHAZ_RANGED_2 = register("chaz_ranged_2",
			EntityType.Builder.<ChazRanged2Entity>of(ChazRanged2Entity::new, MobCategory.MISC).setShouldReceiveVelocityUpdates(true).setTrackingRange(64).setUpdateInterval(1).sized(0.5f, 0.5f));
	public static final DeferredHolder<EntityType<?>, EntityType<SenseiEntity>> SENSEI = register("sensei",
			EntityType.Builder.<SenseiEntity>of(SenseiEntity::new, MobCategory.MONSTER).setShouldReceiveVelocityUpdates(true).setTrackingRange(64).setUpdateInterval(3)

					.sized(0.6f, 1.8f));
	public static final DeferredHolder<EntityType<?>, EntityType<SenseiEntityProjectile>> SENSEI_PROJECTILE = register("projectile_sensei",
			EntityType.Builder.<SenseiEntityProjectile>of(SenseiEntityProjectile::new, MobCategory.MISC).setShouldReceiveVelocityUpdates(true).setTrackingRange(64).setUpdateInterval(1).sized(0.5f, 0.5f));
	public static final DeferredHolder<EntityType<?>, EntityType<PopProjectEntity>> POP_PROJECT = register("pop_project",
			EntityType.Builder.<PopProjectEntity>of(PopProjectEntity::new, MobCategory.MISC).setShouldReceiveVelocityUpdates(true).setTrackingRange(64).setUpdateInterval(1).sized(0.5f, 0.5f));
	public static final DeferredHolder<EntityType<?>, EntityType<PopModEntity>> POP_PIG = register("pop_pig",
			EntityType.Builder.<PopModEntity>of(PopModEntity::new, MobCategory.CREATURE).setShouldReceiveVelocityUpdates(true).setTrackingRange(64).setUpdateInterval(3)

					.sized(0.9f, 0.9f));
	public static final DeferredHolder<EntityType<?>, EntityType<PopModEntityProjectile>> POP_PIG_PROJECTILE = register("projectile_pop_pig",
			EntityType.Builder.<PopModEntityProjectile>of(PopModEntityProjectile::new, MobCategory.MISC).setShouldReceiveVelocityUpdates(true).setTrackingRange(64).setUpdateInterval(1).sized(0.5f, 0.5f));
	public static final DeferredHolder<EntityType<?>, EntityType<PopCatEntity>> POP_CAT = register("pop_cat",
			EntityType.Builder.<PopCatEntity>of(PopCatEntity::new, MobCategory.MONSTER).setShouldReceiveVelocityUpdates(true).setTrackingRange(64).setUpdateInterval(3).fireImmune().sized(0.6f, 0.7f));

	private static <T extends Entity> DeferredHolder<EntityType<?>, EntityType<T>> register(String registryname, EntityType.Builder<T> entityTypeBuilder) {
		return REGISTRY.register(registryname, () -> (EntityType<T>) entityTypeBuilder.build(registryname));
	}

	@SubscribeEvent
	public static void init(SpawnPlacementRegisterEvent event) {
		StarChickenEntity.init(event);
		SenseiEntity.init(event);
		PopModEntity.init(event);
		PopCatEntity.init(event);
	}

	@SubscribeEvent
	public static void registerAttributes(EntityAttributeCreationEvent event) {
		event.put(STAR_CHICKEN.get(), StarChickenEntity.createAttributes().build());
		event.put(SENSEI.get(), SenseiEntity.createAttributes().build());
		event.put(POP_PIG.get(), PopModEntity.createAttributes().build());
		event.put(POP_CAT.get(), PopCatEntity.createAttributes().build());
	}
}
