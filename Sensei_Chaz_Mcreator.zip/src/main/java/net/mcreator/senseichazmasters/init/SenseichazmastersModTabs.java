
/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.senseichazmasters.init;

import net.neoforged.neoforge.registries.DeferredRegister;
import net.neoforged.neoforge.registries.DeferredHolder;
import net.neoforged.neoforge.event.BuildCreativeModeTabContentsEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.bus.api.SubscribeEvent;

import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.CreativeModeTabs;
import net.minecraft.world.item.CreativeModeTab;
import net.minecraft.network.chat.Component;
import net.minecraft.core.registries.Registries;

import net.mcreator.senseichazmasters.SenseichazmastersMod;

@EventBusSubscriber(bus = EventBusSubscriber.Bus.MOD)
public class SenseichazmastersModTabs {
	public static final DeferredRegister<CreativeModeTab> REGISTRY = DeferredRegister.create(Registries.CREATIVE_MODE_TAB, SenseichazmastersMod.MODID);
	public static final DeferredHolder<CreativeModeTab, CreativeModeTab> CHAZ_MOD = REGISTRY.register("chaz_mod",
			() -> CreativeModeTab.builder().title(Component.translatable("item_group.senseichazmasters.chaz_mod")).icon(() -> new ItemStack(SenseichazmastersModItems.C_HAZ_RANGED_1.get())).displayItems((parameters, tabData) -> {
				tabData.accept(SenseichazmastersModBlocks.STAR_SAND.get().asItem());
				tabData.accept(SenseichazmastersModBlocks.SENSEI_SMILE.get().asItem());
				tabData.accept(SenseichazmastersModBlocks.POPTARTIUM.get().asItem());
				tabData.accept(SenseichazmastersModItems.POPTART.get());
			}).withSearchBar().build());
	public static final DeferredHolder<CreativeModeTab, CreativeModeTab> POPTART_MOD = REGISTRY.register("poptart_mod",
			() -> CreativeModeTab.builder().title(Component.translatable("item_group.senseichazmasters.poptart_mod")).icon(() -> new ItemStack(SenseichazmastersModItems.POPTART.get())).displayItems((parameters, tabData) -> {
				tabData.accept(SenseichazmastersModBlocks.POPTARTIUM.get().asItem());
				tabData.accept(SenseichazmastersModItems.POPTART.get());
				tabData.accept(SenseichazmastersModItems.POPTART_SWORD.get());
				tabData.accept(SenseichazmastersModItems.POPTART_PICKAXE.get());
				tabData.accept(SenseichazmastersModItems.POPTART_AXE.get());
				tabData.accept(SenseichazmastersModItems.POPTART_ARMOR_HELMET.get());
				tabData.accept(SenseichazmastersModItems.POPTART_ARMOR_CHESTPLATE.get());
				tabData.accept(SenseichazmastersModItems.POPTART_ARMOR_LEGGINGS.get());
				tabData.accept(SenseichazmastersModItems.POPTART_ARMOR_BOOTS.get());
				tabData.accept(SenseichazmastersModItems.THROWING_POPTART.get());
				tabData.accept(SenseichazmastersModItems.POP_PIG_SPAWN_EGG.get());
				tabData.accept(SenseichazmastersModItems.POP_CAT_SPAWN_EGG.get());
				tabData.accept(SenseichazmastersModBlocks.POP_PLANT_YOUNG.get().asItem());
			}).withSearchBar().build());

	@SubscribeEvent
	public static void buildTabContentsVanilla(BuildCreativeModeTabContentsEvent tabData) {
		if (tabData.getTabKey() == CreativeModeTabs.REDSTONE_BLOCKS) {
			tabData.accept(SenseichazmastersModBlocks.NINJA_TNT.get().asItem());
			tabData.accept(SenseichazmastersModBlocks.DR_SUPER_TNT.get().asItem());
		} else if (tabData.getTabKey() == CreativeModeTabs.COMBAT) {
			tabData.accept(SenseichazmastersModItems.NINJA_WEAPON.get());
			tabData.accept(SenseichazmastersModItems.NINJA_ARMOR_HELMET.get());
			tabData.accept(SenseichazmastersModItems.NINJA_ARMOR_CHESTPLATE.get());
			tabData.accept(SenseichazmastersModItems.NINJA_ARMOR_LEGGINGS.get());
			tabData.accept(SenseichazmastersModItems.NINJA_ARMOR_BOOTS.get());
			tabData.accept(SenseichazmastersModItems.DR_NINJA_SWORD.get());
			tabData.accept(SenseichazmastersModItems.CHAZ_ARMOE_HELMET.get());
			tabData.accept(SenseichazmastersModItems.CHAZ_ARMOE_CHESTPLATE.get());
			tabData.accept(SenseichazmastersModItems.CHAZ_ARMOE_LEGGINGS.get());
			tabData.accept(SenseichazmastersModItems.CHAZ_ARMOE_BOOTS.get());
			tabData.accept(SenseichazmastersModItems.POPTART_SWORD.get());
			tabData.accept(SenseichazmastersModItems.POPTART_ARMOR_HELMET.get());
			tabData.accept(SenseichazmastersModItems.POPTART_ARMOR_CHESTPLATE.get());
			tabData.accept(SenseichazmastersModItems.POPTART_ARMOR_LEGGINGS.get());
			tabData.accept(SenseichazmastersModItems.POPTART_ARMOR_BOOTS.get());
		} else if (tabData.getTabKey() == CreativeModeTabs.SPAWN_EGGS) {
			tabData.accept(SenseichazmastersModItems.STAR_CHICKEN_SPAWN_EGG.get());
			tabData.accept(SenseichazmastersModItems.SENSEI_SPAWN_EGG.get());
			tabData.accept(SenseichazmastersModItems.POP_PIG_SPAWN_EGG.get());
			tabData.accept(SenseichazmastersModItems.POP_CAT_SPAWN_EGG.get());
		} else if (tabData.getTabKey() == CreativeModeTabs.INGREDIENTS) {
			tabData.accept(SenseichazmastersModItems.NINJA_ORE.get());
			tabData.accept(SenseichazmastersModItems.NINJA_INGOT.get());
			tabData.accept(SenseichazmastersModItems.INDIGOIUM_FLOWER.get());
			tabData.accept(SenseichazmastersModItems.CHAZ_INGOT.get());
			tabData.accept(SenseichazmastersModItems.POPTART.get());
		} else if (tabData.getTabKey() == CreativeModeTabs.NATURAL_BLOCKS) {
			tabData.accept(SenseichazmastersModBlocks.NINJA_ORE_BLOCK.get().asItem());
			tabData.accept(SenseichazmastersModBlocks.STAR_DIRT.get().asItem());
			tabData.accept(SenseichazmastersModBlocks.STAR_GRASS.get().asItem());
			tabData.accept(SenseichazmastersModBlocks.STAR_LOG.get().asItem());
			tabData.accept(SenseichazmastersModBlocks.STAR_LEAF.get().asItem());
			tabData.accept(SenseichazmastersModBlocks.STAR_FLOWER.get().asItem());
			tabData.accept(SenseichazmastersModBlocks.DR_NINJA_ORE_BLOCK.get().asItem());
			tabData.accept(SenseichazmastersModBlocks.DR_LOG.get().asItem());
			tabData.accept(SenseichazmastersModBlocks.DR_PLANT.get().asItem());
			tabData.accept(SenseichazmastersModItems.INDIGOIUM_SEEDS.get());
			tabData.accept(SenseichazmastersModBlocks.INDIGOIUM.get().asItem());
			tabData.accept(SenseichazmastersModBlocks.SKY_DIRT.get().asItem());
			tabData.accept(SenseichazmastersModBlocks.POP_PLANT_YOUNG.get().asItem());
		} else if (tabData.getTabKey() == CreativeModeTabs.TOOLS_AND_UTILITIES) {
			tabData.accept(SenseichazmastersModItems.POPTART_PICKAXE.get());
			tabData.accept(SenseichazmastersModItems.POPTART_AXE.get());
		}
	}
}
