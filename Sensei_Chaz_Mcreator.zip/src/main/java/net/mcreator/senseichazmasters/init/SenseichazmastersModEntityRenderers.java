
/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.senseichazmasters.init;

import net.neoforged.neoforge.client.event.EntityRenderersEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.api.distmarker.Dist;

import net.minecraft.client.renderer.entity.ThrownItemRenderer;

import net.mcreator.senseichazmasters.client.renderer.StarChickenRenderer;
import net.mcreator.senseichazmasters.client.renderer.SenseiRenderer;
import net.mcreator.senseichazmasters.client.renderer.PopModRenderer;
import net.mcreator.senseichazmasters.client.renderer.PopCatRenderer;

@EventBusSubscriber(bus = EventBusSubscriber.Bus.MOD, value = Dist.CLIENT)
public class SenseichazmastersModEntityRenderers {
	@SubscribeEvent
	public static void registerEntityRenderers(EntityRenderersEvent.RegisterRenderers event) {
		event.registerEntityRenderer(SenseichazmastersModEntities.STAR_CHICKEN.get(), StarChickenRenderer::new);
		event.registerEntityRenderer(SenseichazmastersModEntities.STAR_CHICKEN_PROJECTILE.get(), ThrownItemRenderer::new);
		event.registerEntityRenderer(SenseichazmastersModEntities.PROJECTILE.get(), ThrownItemRenderer::new);
		event.registerEntityRenderer(SenseichazmastersModEntities.CHAZ_RANGED_2.get(), ThrownItemRenderer::new);
		event.registerEntityRenderer(SenseichazmastersModEntities.SENSEI.get(), SenseiRenderer::new);
		event.registerEntityRenderer(SenseichazmastersModEntities.SENSEI_PROJECTILE.get(), ThrownItemRenderer::new);
		event.registerEntityRenderer(SenseichazmastersModEntities.POP_PROJECT.get(), ThrownItemRenderer::new);
		event.registerEntityRenderer(SenseichazmastersModEntities.POP_PIG.get(), PopModRenderer::new);
		event.registerEntityRenderer(SenseichazmastersModEntities.POP_PIG_PROJECTILE.get(), ThrownItemRenderer::new);
		event.registerEntityRenderer(SenseichazmastersModEntities.POP_CAT.get(), PopCatRenderer::new);
	}
}
