
/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.senseichazmasters.init;

import net.neoforged.neoforge.registries.DeferredRegister;
import net.neoforged.neoforge.registries.DeferredHolder;
import net.neoforged.neoforge.client.event.RegisterColorHandlersEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.api.distmarker.Dist;

import net.minecraft.world.level.block.Block;

import net.mcreator.senseichazmasters.block.StarSandBlock;
import net.mcreator.senseichazmasters.block.StarLogBlock;
import net.mcreator.senseichazmasters.block.StarLeafBlock;
import net.mcreator.senseichazmasters.block.StarGrassBlock;
import net.mcreator.senseichazmasters.block.StarFlowerBlock;
import net.mcreator.senseichazmasters.block.StarDirtBlock;
import net.mcreator.senseichazmasters.block.SkyDirtBlock;
import net.mcreator.senseichazmasters.block.SenseiSmileBlock;
import net.mcreator.senseichazmasters.block.PoptartiumBlock;
import net.mcreator.senseichazmasters.block.PopPlantYoungBlock;
import net.mcreator.senseichazmasters.block.PopPlantBlock;
import net.mcreator.senseichazmasters.block.NinjaTNTBlock;
import net.mcreator.senseichazmasters.block.NinjaOreBlockBlock;
import net.mcreator.senseichazmasters.block.IndigoiumStage4Block;
import net.mcreator.senseichazmasters.block.IndigoiumStage3Block;
import net.mcreator.senseichazmasters.block.IndigoiumStage2Block;
import net.mcreator.senseichazmasters.block.IndigoiumStage1Block;
import net.mcreator.senseichazmasters.block.IndigoiumBlock;
import net.mcreator.senseichazmasters.block.DrSuperTNTBlock;
import net.mcreator.senseichazmasters.block.DrNinjaOreBlockBlock;
import net.mcreator.senseichazmasters.block.DRPlantBlock;
import net.mcreator.senseichazmasters.block.DRLogBlock;
import net.mcreator.senseichazmasters.SenseichazmastersMod;

public class SenseichazmastersModBlocks {
	public static final DeferredRegister.Blocks REGISTRY = DeferredRegister.createBlocks(SenseichazmastersMod.MODID);
	public static final DeferredHolder<Block, Block> NINJA_ORE_BLOCK = REGISTRY.register("ninja_ore_block", NinjaOreBlockBlock::new);
	public static final DeferredHolder<Block, Block> NINJA_TNT = REGISTRY.register("ninja_tnt", NinjaTNTBlock::new);
	public static final DeferredHolder<Block, Block> STAR_DIRT = REGISTRY.register("star_dirt", StarDirtBlock::new);
	public static final DeferredHolder<Block, Block> STAR_GRASS = REGISTRY.register("star_grass", StarGrassBlock::new);
	public static final DeferredHolder<Block, Block> STAR_LOG = REGISTRY.register("star_log", StarLogBlock::new);
	public static final DeferredHolder<Block, Block> STAR_SAND = REGISTRY.register("star_sand", StarSandBlock::new);
	public static final DeferredHolder<Block, Block> STAR_LEAF = REGISTRY.register("star_leaf", StarLeafBlock::new);
	public static final DeferredHolder<Block, Block> STAR_FLOWER = REGISTRY.register("star_flower", StarFlowerBlock::new);
	public static final DeferredHolder<Block, Block> DR_NINJA_ORE_BLOCK = REGISTRY.register("dr_ninja_ore_block", DrNinjaOreBlockBlock::new);
	public static final DeferredHolder<Block, Block> DR_SUPER_TNT = REGISTRY.register("dr_super_tnt", DrSuperTNTBlock::new);
	public static final DeferredHolder<Block, Block> DR_LOG = REGISTRY.register("dr_log", DRLogBlock::new);
	public static final DeferredHolder<Block, Block> DR_PLANT = REGISTRY.register("dr_plant", DRPlantBlock::new);
	public static final DeferredHolder<Block, Block> INDIGOIUM = REGISTRY.register("indigoium", IndigoiumBlock::new);
	public static final DeferredHolder<Block, Block> INDIGOIUM_STAGE_1 = REGISTRY.register("indigoium_stage_1", IndigoiumStage1Block::new);
	public static final DeferredHolder<Block, Block> INDIGOIUM_STAGE_2 = REGISTRY.register("indigoium_stage_2", IndigoiumStage2Block::new);
	public static final DeferredHolder<Block, Block> INDIGOIUM_STAGE_3 = REGISTRY.register("indigoium_stage_3", IndigoiumStage3Block::new);
	public static final DeferredHolder<Block, Block> INDIGOIUM_STAGE_4 = REGISTRY.register("indigoium_stage_4", IndigoiumStage4Block::new);
	public static final DeferredHolder<Block, Block> SKY_DIRT = REGISTRY.register("sky_dirt", SkyDirtBlock::new);
	public static final DeferredHolder<Block, Block> SENSEI_SMILE = REGISTRY.register("sensei_smile", SenseiSmileBlock::new);
	public static final DeferredHolder<Block, Block> POPTARTIUM = REGISTRY.register("poptartium", PoptartiumBlock::new);
	public static final DeferredHolder<Block, Block> POP_PLANT = REGISTRY.register("pop_plant", PopPlantBlock::new);
	public static final DeferredHolder<Block, Block> POP_PLANT_YOUNG = REGISTRY.register("pop_plant_young", PopPlantYoungBlock::new);

	// Start of user code block custom blocks
	// End of user code block custom blocks
	@EventBusSubscriber(bus = EventBusSubscriber.Bus.MOD, value = Dist.CLIENT)
	public static class BlocksClientSideHandler {
		@SubscribeEvent
		public static void blockColorLoad(RegisterColorHandlersEvent.Block event) {
			IndigoiumBlock.blockColorLoad(event);
			IndigoiumStage1Block.blockColorLoad(event);
			IndigoiumStage2Block.blockColorLoad(event);
			IndigoiumStage3Block.blockColorLoad(event);
			IndigoiumStage4Block.blockColorLoad(event);
		}
	}
}
