
/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.senseichazmasters.init;

import net.neoforged.neoforge.registries.DeferredRegister;
import net.neoforged.neoforge.registries.DeferredHolder;
import net.neoforged.neoforge.common.DeferredSpawnEggItem;

import net.minecraft.world.level.block.Block;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.BlockItem;

import net.mcreator.senseichazmasters.item.ThrowingPoptartItem;
import net.mcreator.senseichazmasters.item.PoptartSwordItem;
import net.mcreator.senseichazmasters.item.PoptartPickaxeItem;
import net.mcreator.senseichazmasters.item.PoptartItem;
import net.mcreator.senseichazmasters.item.PoptartAxeItem;
import net.mcreator.senseichazmasters.item.PoptartArmorItem;
import net.mcreator.senseichazmasters.item.NinjaWeaponItem;
import net.mcreator.senseichazmasters.item.NinjaOreItem;
import net.mcreator.senseichazmasters.item.NinjaIngotItem;
import net.mcreator.senseichazmasters.item.NinjaArmorItem;
import net.mcreator.senseichazmasters.item.IndigoiumSeedsItem;
import net.mcreator.senseichazmasters.item.IndigoiumFlowerItem;
import net.mcreator.senseichazmasters.item.DRNinjaSwordItem;
import net.mcreator.senseichazmasters.item.DRNinjaOreItem;
import net.mcreator.senseichazmasters.item.DRNinjaIngotItem;
import net.mcreator.senseichazmasters.item.ChazIngotItem;
import net.mcreator.senseichazmasters.item.ChazArmoeItem;
import net.mcreator.senseichazmasters.item.CHazRanged1Item;
import net.mcreator.senseichazmasters.SenseichazmastersMod;

public class SenseichazmastersModItems {
	public static final DeferredRegister.Items REGISTRY = DeferredRegister.createItems(SenseichazmastersMod.MODID);
	public static final DeferredHolder<Item, Item> NINJA_ORE = REGISTRY.register("ninja_ore", NinjaOreItem::new);
	public static final DeferredHolder<Item, Item> NINJA_ORE_BLOCK = block(SenseichazmastersModBlocks.NINJA_ORE_BLOCK);
	public static final DeferredHolder<Item, Item> NINJA_INGOT = REGISTRY.register("ninja_ingot", NinjaIngotItem::new);
	public static final DeferredHolder<Item, Item> NINJA_WEAPON = REGISTRY.register("ninja_weapon", NinjaWeaponItem::new);
	public static final DeferredHolder<Item, Item> NINJA_TNT = block(SenseichazmastersModBlocks.NINJA_TNT);
	public static final DeferredHolder<Item, Item> NINJA_ARMOR_HELMET = REGISTRY.register("ninja_armor_helmet", NinjaArmorItem.Helmet::new);
	public static final DeferredHolder<Item, Item> NINJA_ARMOR_CHESTPLATE = REGISTRY.register("ninja_armor_chestplate", NinjaArmorItem.Chestplate::new);
	public static final DeferredHolder<Item, Item> NINJA_ARMOR_LEGGINGS = REGISTRY.register("ninja_armor_leggings", NinjaArmorItem.Leggings::new);
	public static final DeferredHolder<Item, Item> NINJA_ARMOR_BOOTS = REGISTRY.register("ninja_armor_boots", NinjaArmorItem.Boots::new);
	public static final DeferredHolder<Item, Item> STAR_DIRT = block(SenseichazmastersModBlocks.STAR_DIRT);
	public static final DeferredHolder<Item, Item> STAR_GRASS = block(SenseichazmastersModBlocks.STAR_GRASS);
	public static final DeferredHolder<Item, Item> STAR_LOG = block(SenseichazmastersModBlocks.STAR_LOG);
	public static final DeferredHolder<Item, Item> STAR_SAND = block(SenseichazmastersModBlocks.STAR_SAND);
	public static final DeferredHolder<Item, Item> STAR_LEAF = block(SenseichazmastersModBlocks.STAR_LEAF);
	public static final DeferredHolder<Item, Item> STAR_FLOWER = block(SenseichazmastersModBlocks.STAR_FLOWER);
	public static final DeferredHolder<Item, Item> STAR_CHICKEN_SPAWN_EGG = REGISTRY.register("star_chicken_spawn_egg", () -> new DeferredSpawnEggItem(SenseichazmastersModEntities.STAR_CHICKEN, -103, -52276, new Item.Properties()));
	public static final DeferredHolder<Item, Item> DR_NINJA_ORE = REGISTRY.register("dr_ninja_ore", DRNinjaOreItem::new);
	public static final DeferredHolder<Item, Item> DR_NINJA_ORE_BLOCK = block(SenseichazmastersModBlocks.DR_NINJA_ORE_BLOCK);
	public static final DeferredHolder<Item, Item> DR_NINJA_INGOT = REGISTRY.register("dr_ninja_ingot", DRNinjaIngotItem::new);
	public static final DeferredHolder<Item, Item> DR_NINJA_SWORD = REGISTRY.register("dr_ninja_sword", DRNinjaSwordItem::new);
	public static final DeferredHolder<Item, Item> DR_SUPER_TNT = block(SenseichazmastersModBlocks.DR_SUPER_TNT);
	public static final DeferredHolder<Item, Item> DR_LOG = block(SenseichazmastersModBlocks.DR_LOG);
	public static final DeferredHolder<Item, Item> DR_PLANT = block(SenseichazmastersModBlocks.DR_PLANT);
	public static final DeferredHolder<Item, Item> INDIGOIUM_FLOWER = REGISTRY.register("indigoium_flower", IndigoiumFlowerItem::new);
	public static final DeferredHolder<Item, Item> INDIGOIUM_SEEDS = REGISTRY.register("indigoium_seeds", IndigoiumSeedsItem::new);
	public static final DeferredHolder<Item, Item> INDIGOIUM = block(SenseichazmastersModBlocks.INDIGOIUM);
	public static final DeferredHolder<Item, Item> INDIGOIUM_STAGE_1 = block(SenseichazmastersModBlocks.INDIGOIUM_STAGE_1);
	public static final DeferredHolder<Item, Item> INDIGOIUM_STAGE_2 = block(SenseichazmastersModBlocks.INDIGOIUM_STAGE_2);
	public static final DeferredHolder<Item, Item> INDIGOIUM_STAGE_3 = block(SenseichazmastersModBlocks.INDIGOIUM_STAGE_3);
	public static final DeferredHolder<Item, Item> INDIGOIUM_STAGE_4 = block(SenseichazmastersModBlocks.INDIGOIUM_STAGE_4);
	public static final DeferredHolder<Item, Item> SKY_DIRT = block(SenseichazmastersModBlocks.SKY_DIRT);
	public static final DeferredHolder<Item, Item> CHAZ_INGOT = REGISTRY.register("chaz_ingot", ChazIngotItem::new);
	public static final DeferredHolder<Item, Item> CHAZ_ARMOE_HELMET = REGISTRY.register("chaz_armoe_helmet", ChazArmoeItem.Helmet::new);
	public static final DeferredHolder<Item, Item> CHAZ_ARMOE_CHESTPLATE = REGISTRY.register("chaz_armoe_chestplate", ChazArmoeItem.Chestplate::new);
	public static final DeferredHolder<Item, Item> CHAZ_ARMOE_LEGGINGS = REGISTRY.register("chaz_armoe_leggings", ChazArmoeItem.Leggings::new);
	public static final DeferredHolder<Item, Item> CHAZ_ARMOE_BOOTS = REGISTRY.register("chaz_armoe_boots", ChazArmoeItem.Boots::new);
	public static final DeferredHolder<Item, Item> C_HAZ_RANGED_1 = REGISTRY.register("c_haz_ranged_1", CHazRanged1Item::new);
	public static final DeferredHolder<Item, Item> SENSEI_SPAWN_EGG = REGISTRY.register("sensei_spawn_egg", () -> new DeferredSpawnEggItem(SenseichazmastersModEntities.SENSEI, -13369600, -65536, new Item.Properties()));
	public static final DeferredHolder<Item, Item> SENSEI_SMILE = block(SenseichazmastersModBlocks.SENSEI_SMILE);
	public static final DeferredHolder<Item, Item> POPTARTIUM = block(SenseichazmastersModBlocks.POPTARTIUM);
	public static final DeferredHolder<Item, Item> POPTART = REGISTRY.register("poptart", PoptartItem::new);
	public static final DeferredHolder<Item, Item> POPTART_SWORD = REGISTRY.register("poptart_sword", PoptartSwordItem::new);
	public static final DeferredHolder<Item, Item> POPTART_PICKAXE = REGISTRY.register("poptart_pickaxe", PoptartPickaxeItem::new);
	public static final DeferredHolder<Item, Item> POPTART_AXE = REGISTRY.register("poptart_axe", PoptartAxeItem::new);
	public static final DeferredHolder<Item, Item> POPTART_ARMOR_HELMET = REGISTRY.register("poptart_armor_helmet", PoptartArmorItem.Helmet::new);
	public static final DeferredHolder<Item, Item> POPTART_ARMOR_CHESTPLATE = REGISTRY.register("poptart_armor_chestplate", PoptartArmorItem.Chestplate::new);
	public static final DeferredHolder<Item, Item> POPTART_ARMOR_LEGGINGS = REGISTRY.register("poptart_armor_leggings", PoptartArmorItem.Leggings::new);
	public static final DeferredHolder<Item, Item> POPTART_ARMOR_BOOTS = REGISTRY.register("poptart_armor_boots", PoptartArmorItem.Boots::new);
	public static final DeferredHolder<Item, Item> THROWING_POPTART = REGISTRY.register("throwing_poptart", ThrowingPoptartItem::new);
	public static final DeferredHolder<Item, Item> POP_PIG_SPAWN_EGG = REGISTRY.register("pop_pig_spawn_egg", () -> new DeferredSpawnEggItem(SenseichazmastersModEntities.POP_PIG, -18610, -1340960, new Item.Properties()));
	public static final DeferredHolder<Item, Item> POP_CAT_SPAWN_EGG = REGISTRY.register("pop_cat_spawn_egg", () -> new DeferredSpawnEggItem(SenseichazmastersModEntities.POP_CAT, -1936340, -833841, new Item.Properties()));
	public static final DeferredHolder<Item, Item> POP_PLANT = block(SenseichazmastersModBlocks.POP_PLANT);
	public static final DeferredHolder<Item, Item> POP_PLANT_YOUNG = block(SenseichazmastersModBlocks.POP_PLANT_YOUNG);

	// Start of user code block custom items
	// End of user code block custom items
	private static DeferredHolder<Item, Item> block(DeferredHolder<Block, Block> block) {
		return REGISTRY.register(block.getId().getPath(), () -> new BlockItem(block.get(), new Item.Properties()));
	}
}
