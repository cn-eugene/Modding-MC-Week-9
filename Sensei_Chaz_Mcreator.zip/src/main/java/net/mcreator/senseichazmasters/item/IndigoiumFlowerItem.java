
package net.mcreator.senseichazmasters.item;

import net.minecraft.world.item.Rarity;
import net.minecraft.world.item.Item;

public class IndigoiumFlowerItem extends Item {
	public IndigoiumFlowerItem() {
		super(new Item.Properties().stacksTo(64).rarity(Rarity.COMMON));
	}
}
