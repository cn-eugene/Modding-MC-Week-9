package net.mcreator.senseichazmasters.procedures;

import net.minecraft.world.entity.Entity;
import net.minecraft.util.RandomSource;
import net.minecraft.util.Mth;
import net.minecraft.server.level.ServerPlayer;

public class PopModThisEntityKillsAnotherOneProcedure {
	public static void execute(double x, double y, double z, Entity entity) {
		if (entity == null)
			return;
		{
			Entity _ent = entity;
			_ent.teleportTo((x * (Mth.nextInt(RandomSource.create(), 1, 10) + Math.random())), (y * (Mth.nextInt(RandomSource.create(), 1, 10) + Math.random())), (z * (Mth.nextInt(RandomSource.create(), 1, 10) + Math.random())));
			if (_ent instanceof ServerPlayer _serverPlayer)
				_serverPlayer.connection.teleport((x * (Mth.nextInt(RandomSource.create(), 1, 10) + Math.random())), (y * (Mth.nextInt(RandomSource.create(), 1, 10) + Math.random())), (z * (Mth.nextInt(RandomSource.create(), 1, 10) + Math.random())),
						_ent.getYRot(), _ent.getXRot());
		}
	}
}
