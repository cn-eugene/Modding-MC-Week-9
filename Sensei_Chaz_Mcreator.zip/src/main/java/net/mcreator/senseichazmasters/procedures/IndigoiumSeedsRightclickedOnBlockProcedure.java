package net.mcreator.senseichazmasters.procedures;

import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.LevelAccessor;
import net.minecraft.core.BlockPos;

import net.mcreator.senseichazmasters.init.SenseichazmastersModBlocks;

public class IndigoiumSeedsRightclickedOnBlockProcedure {
	public static void execute(LevelAccessor world, double x, double y, double z) {
		if ((world.getBlockState(BlockPos.containing(x, y, z))).getBlock() == Blocks.FARMLAND) {
			world.setBlock(BlockPos.containing(x, y + 1, z), SenseichazmastersModBlocks.INDIGOIUM.get().defaultBlockState(), 3);
		}
	}
}
