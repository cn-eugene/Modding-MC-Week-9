package net.mcreator.senseichazmasters.procedures;

import net.minecraft.world.level.LevelAccessor;
import net.minecraft.core.BlockPos;

import net.mcreator.senseichazmasters.init.SenseichazmastersModBlocks;

public class IndigoiumStage23Procedure {
	public static void execute(LevelAccessor world, double x, double y, double z) {
		double RandomNumber = 0;
		RandomNumber = Math.random() * 100;
		if (RandomNumber <= 5) {
			world.setBlock(BlockPos.containing(x, y, z), SenseichazmastersModBlocks.INDIGOIUM_STAGE_1.get().defaultBlockState(), 3);
		}
	}
}
