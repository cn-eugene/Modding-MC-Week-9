
package net.mcreator.senseichazmasters.client.renderer;

import net.minecraft.resources.ResourceLocation;
import net.minecraft.client.renderer.entity.MobRenderer;
import net.minecraft.client.renderer.entity.EntityRendererProvider;
import net.minecraft.client.model.geom.ModelLayers;
import net.minecraft.client.model.ChickenModel;

import net.mcreator.senseichazmasters.entity.StarChickenEntity;

public class StarChickenRenderer extends MobRenderer<StarChickenEntity, ChickenModel<StarChickenEntity>> {
	public StarChickenRenderer(EntityRendererProvider.Context context) {
		super(context, new ChickenModel(context.bakeLayer(ModelLayers.CHICKEN)), 0.5f);
	}

	@Override
	public ResourceLocation getTextureLocation(StarChickenEntity entity) {
		return new ResourceLocation("senseichazmasters:textures/entities/chicken.png");
	}
}
