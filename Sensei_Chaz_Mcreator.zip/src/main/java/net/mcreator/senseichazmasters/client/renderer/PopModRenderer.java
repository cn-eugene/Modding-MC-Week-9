
package net.mcreator.senseichazmasters.client.renderer;

import net.minecraft.resources.ResourceLocation;
import net.minecraft.client.renderer.entity.MobRenderer;
import net.minecraft.client.renderer.entity.EntityRendererProvider;
import net.minecraft.client.model.geom.ModelLayers;
import net.minecraft.client.model.PigModel;

import net.mcreator.senseichazmasters.entity.PopModEntity;

public class PopModRenderer extends MobRenderer<PopModEntity, PigModel<PopModEntity>> {
	public PopModRenderer(EntityRendererProvider.Context context) {
		super(context, new PigModel(context.bakeLayer(ModelLayers.PIG)), 0.5f);
	}

	@Override
	public ResourceLocation getTextureLocation(PopModEntity entity) {
		return new ResourceLocation("senseichazmasters:textures/entities/pig_2.png");
	}
}
