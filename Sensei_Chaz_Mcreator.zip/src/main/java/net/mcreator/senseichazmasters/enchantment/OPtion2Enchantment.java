
package net.mcreator.senseichazmasters.enchantment;

import net.minecraft.world.item.enchantment.Enchantment;
import net.minecraft.world.entity.EquipmentSlot;
import net.minecraft.tags.ItemTags;

public class OPtion2Enchantment extends Enchantment {
	public OPtion2Enchantment(EquipmentSlot... slots) {
		super(Enchantment.definition(ItemTags.DURABILITY_ENCHANTABLE, 10, 1, Enchantment.dynamicCost(1, 10), Enchantment.dynamicCost(6, 10), 1, EquipmentSlot.values()));
	}
}
