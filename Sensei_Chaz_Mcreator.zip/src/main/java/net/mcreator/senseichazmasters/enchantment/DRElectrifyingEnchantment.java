
package net.mcreator.senseichazmasters.enchantment;

import net.minecraft.world.item.enchantment.Enchantment;
import net.minecraft.world.entity.EquipmentSlot;
import net.minecraft.tags.ItemTags;

public class DRElectrifyingEnchantment extends Enchantment {
	public DRElectrifyingEnchantment(EquipmentSlot... slots) {
		super(Enchantment.definition(ItemTags.WEAPON_ENCHANTABLE, 10, 1, Enchantment.dynamicCost(1, 10), Enchantment.dynamicCost(6, 10), 1, EquipmentSlot.MAINHAND));
	}
}
