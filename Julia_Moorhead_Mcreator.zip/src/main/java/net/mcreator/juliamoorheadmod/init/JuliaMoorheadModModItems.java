
/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.juliamoorheadmod.init;

import net.neoforged.neoforge.registries.DeferredRegister;
import net.neoforged.neoforge.registries.DeferredHolder;
import net.neoforged.neoforge.common.DeferredSpawnEggItem;

import net.minecraft.world.level.block.Block;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.BlockItem;

import net.mcreator.juliamoorheadmod.item.StrawberryItem;
import net.mcreator.juliamoorheadmod.item.SoulfirechargeItem;
import net.mcreator.juliamoorheadmod.item.Melltedchocolate2Item;
import net.mcreator.juliamoorheadmod.item.LaggedswordItem;
import net.mcreator.juliamoorheadmod.item.LaggedingotItem;
import net.mcreator.juliamoorheadmod.item.LaggedaxeItem;
import net.mcreator.juliamoorheadmod.item.LaggedarmorItem;
import net.mcreator.juliamoorheadmod.item.ChocolatecoverdstrawberryItem;
import net.mcreator.juliamoorheadmod.item.ChocolateItem;
import net.mcreator.juliamoorheadmod.JuliaMoorheadModMod;

public class JuliaMoorheadModModItems {
	public static final DeferredRegister.Items REGISTRY = DeferredRegister.createItems(JuliaMoorheadModMod.MODID);
	public static final DeferredHolder<Item, Item> LAGGEDBLOCK = block(JuliaMoorheadModModBlocks.LAGGEDBLOCK);
	public static final DeferredHolder<Item, Item> CHOCOLATEORE = block(JuliaMoorheadModModBlocks.CHOCOLATEORE);
	public static final DeferredHolder<Item, Item> CHOCOLATE = REGISTRY.register("chocolate", ChocolateItem::new);
	public static final DeferredHolder<Item, Item> LAGGEDINGOT = REGISTRY.register("laggedingot", LaggedingotItem::new);
	public static final DeferredHolder<Item, Item> MELLTEDCHOCOLATE_2 = REGISTRY.register("melltedchocolate_2", Melltedchocolate2Item::new);
	public static final DeferredHolder<Item, Item> LAGGEDSWORD = REGISTRY.register("laggedsword", LaggedswordItem::new);
	public static final DeferredHolder<Item, Item> LAGGEDAXE = REGISTRY.register("laggedaxe", LaggedaxeItem::new);
	public static final DeferredHolder<Item, Item> LAGGEDARMOR_HELMET = REGISTRY.register("laggedarmor_helmet", LaggedarmorItem.Helmet::new);
	public static final DeferredHolder<Item, Item> LAGGEDARMOR_CHESTPLATE = REGISTRY.register("laggedarmor_chestplate", LaggedarmorItem.Chestplate::new);
	public static final DeferredHolder<Item, Item> LAGGEDARMOR_LEGGINGS = REGISTRY.register("laggedarmor_leggings", LaggedarmorItem.Leggings::new);
	public static final DeferredHolder<Item, Item> LAGGEDARMOR_BOOTS = REGISTRY.register("laggedarmor_boots", LaggedarmorItem.Boots::new);
	public static final DeferredHolder<Item, Item> TEST_SPAWN_EGG = REGISTRY.register("test_spawn_egg", () -> new DeferredSpawnEggItem(JuliaMoorheadModModEntities.TEST, -2364374, -423927, new Item.Properties()));
	public static final DeferredHolder<Item, Item> STRAWBERRY = REGISTRY.register("strawberry", StrawberryItem::new);
	public static final DeferredHolder<Item, Item> CHOCOLATECOVERDSTRAWBERRY = REGISTRY.register("chocolatecoverdstrawberry", ChocolatecoverdstrawberryItem::new);
	public static final DeferredHolder<Item, Item> SOULFIRECHARGE = REGISTRY.register("soulfirecharge", SoulfirechargeItem::new);
	public static final DeferredHolder<Item, Item> ENTITY_4646_SPAWN_EGG = REGISTRY.register("entity_4646_spawn_egg", () -> new DeferredSpawnEggItem(JuliaMoorheadModModEntities.ENTITY_4646, -65485, -13369549, new Item.Properties()));
	public static final DeferredHolder<Item, Item> STRAWBERRYBUSH = block(JuliaMoorheadModModBlocks.STRAWBERRYBUSH);
	public static final DeferredHolder<Item, Item> EPICCOP_SPAWN_EGG = REGISTRY.register("epiccop_spawn_egg", () -> new DeferredSpawnEggItem(JuliaMoorheadModModEntities.EPICCOP, -256, -16777012, new Item.Properties()));

	// Start of user code block custom items
	// End of user code block custom items
	private static DeferredHolder<Item, Item> block(DeferredHolder<Block, Block> block) {
		return REGISTRY.register(block.getId().getPath(), () -> new BlockItem(block.get(), new Item.Properties()));
	}
}
