
/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.juliamoorheadmod.init;

import net.neoforged.neoforge.registries.DeferredRegister;
import net.neoforged.neoforge.registries.DeferredHolder;

import net.minecraft.world.level.block.Block;

import net.mcreator.juliamoorheadmod.block.StrawberrybushBlock;
import net.mcreator.juliamoorheadmod.block.LaggedblockBlock;
import net.mcreator.juliamoorheadmod.block.ChocolateoreBlock;
import net.mcreator.juliamoorheadmod.JuliaMoorheadModMod;

public class JuliaMoorheadModModBlocks {
	public static final DeferredRegister.Blocks REGISTRY = DeferredRegister.createBlocks(JuliaMoorheadModMod.MODID);
	public static final DeferredHolder<Block, Block> LAGGEDBLOCK = REGISTRY.register("laggedblock", LaggedblockBlock::new);
	public static final DeferredHolder<Block, Block> CHOCOLATEORE = REGISTRY.register("chocolateore", ChocolateoreBlock::new);
	public static final DeferredHolder<Block, Block> STRAWBERRYBUSH = REGISTRY.register("strawberrybush", StrawberrybushBlock::new);
	// Start of user code block custom blocks
	// End of user code block custom blocks
}
