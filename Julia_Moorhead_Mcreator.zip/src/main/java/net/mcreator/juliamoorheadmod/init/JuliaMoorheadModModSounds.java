
/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.juliamoorheadmod.init;

import net.neoforged.neoforge.registries.DeferredRegister;
import net.neoforged.neoforge.registries.DeferredHolder;

import net.minecraft.sounds.SoundEvent;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.core.registries.Registries;

import net.mcreator.juliamoorheadmod.JuliaMoorheadModMod;

public class JuliaMoorheadModModSounds {
	public static final DeferredRegister<SoundEvent> REGISTRY = DeferredRegister.create(Registries.SOUND_EVENT, JuliaMoorheadModMod.MODID);
	public static final DeferredHolder<SoundEvent, SoundEvent> MONSTERCHICKEN = REGISTRY.register("monsterchicken", () -> SoundEvent.createVariableRangeEvent(new ResourceLocation("julia_moorhead_mod", "monsterchicken")));
	public static final DeferredHolder<SoundEvent, SoundEvent> ENTITY_IWILLFINDYIU = REGISTRY.register("entity.iwillfindyiu", () -> SoundEvent.createVariableRangeEvent(new ResourceLocation("julia_moorhead_mod", "entity.iwillfindyiu")));
	public static final DeferredHolder<SoundEvent, SoundEvent> UNDERARREST = REGISTRY.register("underarrest", () -> SoundEvent.createVariableRangeEvent(new ResourceLocation("julia_moorhead_mod", "underarrest")));
}
