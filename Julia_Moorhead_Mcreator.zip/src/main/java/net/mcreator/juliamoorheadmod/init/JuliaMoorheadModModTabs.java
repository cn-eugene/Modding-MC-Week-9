
/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.juliamoorheadmod.init;

import net.neoforged.neoforge.registries.DeferredRegister;
import net.neoforged.neoforge.event.BuildCreativeModeTabContentsEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.bus.api.SubscribeEvent;

import net.minecraft.world.item.CreativeModeTabs;
import net.minecraft.world.item.CreativeModeTab;
import net.minecraft.core.registries.Registries;

import net.mcreator.juliamoorheadmod.JuliaMoorheadModMod;

@EventBusSubscriber(bus = EventBusSubscriber.Bus.MOD)
public class JuliaMoorheadModModTabs {
	public static final DeferredRegister<CreativeModeTab> REGISTRY = DeferredRegister.create(Registries.CREATIVE_MODE_TAB, JuliaMoorheadModMod.MODID);

	@SubscribeEvent
	public static void buildTabContentsVanilla(BuildCreativeModeTabContentsEvent tabData) {
		if (tabData.getTabKey() == CreativeModeTabs.COMBAT) {
			tabData.accept(JuliaMoorheadModModItems.LAGGEDARMOR_HELMET.get());
			tabData.accept(JuliaMoorheadModModItems.LAGGEDARMOR_CHESTPLATE.get());
			tabData.accept(JuliaMoorheadModModItems.LAGGEDARMOR_LEGGINGS.get());
			tabData.accept(JuliaMoorheadModModItems.LAGGEDARMOR_BOOTS.get());
		} else if (tabData.getTabKey() == CreativeModeTabs.SPAWN_EGGS) {
			tabData.accept(JuliaMoorheadModModItems.TEST_SPAWN_EGG.get());
			tabData.accept(JuliaMoorheadModModItems.ENTITY_4646_SPAWN_EGG.get());
			tabData.accept(JuliaMoorheadModModItems.EPICCOP_SPAWN_EGG.get());
		} else if (tabData.getTabKey() == CreativeModeTabs.INGREDIENTS) {
			tabData.accept(JuliaMoorheadModModBlocks.LAGGEDBLOCK.get().asItem());
			tabData.accept(JuliaMoorheadModModItems.LAGGEDINGOT.get());
		} else if (tabData.getTabKey() == CreativeModeTabs.NATURAL_BLOCKS) {
			tabData.accept(JuliaMoorheadModModBlocks.CHOCOLATEORE.get().asItem());
			tabData.accept(JuliaMoorheadModModBlocks.STRAWBERRYBUSH.get().asItem());
		} else if (tabData.getTabKey() == CreativeModeTabs.FOOD_AND_DRINKS) {
			tabData.accept(JuliaMoorheadModModItems.CHOCOLATE.get());
			tabData.accept(JuliaMoorheadModModItems.STRAWBERRY.get());
			tabData.accept(JuliaMoorheadModModItems.CHOCOLATECOVERDSTRAWBERRY.get());
		} else if (tabData.getTabKey() == CreativeModeTabs.TOOLS_AND_UTILITIES) {
			tabData.accept(JuliaMoorheadModModItems.LAGGEDSWORD.get());
			tabData.accept(JuliaMoorheadModModItems.LAGGEDAXE.get());
		}
	}
}
