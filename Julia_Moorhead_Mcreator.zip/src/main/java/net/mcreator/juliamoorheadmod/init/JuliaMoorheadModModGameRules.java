
/*
 *	MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.juliamoorheadmod.init;

import net.neoforged.fml.event.lifecycle.FMLCommonSetupEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.bus.api.SubscribeEvent;

import net.minecraft.world.level.GameRules;

@EventBusSubscriber(bus = EventBusSubscriber.Bus.MOD)
public class JuliaMoorheadModModGameRules {
	public static GameRules.Key<GameRules.IntegerValue> BABYMODE;

	@SubscribeEvent
	public static void registerGameRules(FMLCommonSetupEvent event) {
		BABYMODE = GameRules.register("babymode", GameRules.Category.PLAYER, GameRules.IntegerValue.create(0));
	}
}
