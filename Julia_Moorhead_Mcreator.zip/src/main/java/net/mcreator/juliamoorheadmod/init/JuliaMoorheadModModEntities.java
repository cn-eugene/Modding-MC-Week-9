
/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.juliamoorheadmod.init;

import net.neoforged.neoforge.registries.DeferredRegister;
import net.neoforged.neoforge.registries.DeferredHolder;
import net.neoforged.neoforge.event.entity.SpawnPlacementRegisterEvent;
import net.neoforged.neoforge.event.entity.EntityAttributeCreationEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.bus.api.SubscribeEvent;

import net.minecraft.world.entity.MobCategory;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.Entity;
import net.minecraft.core.registries.Registries;

import net.mcreator.juliamoorheadmod.entity.TestEntityProjectile;
import net.mcreator.juliamoorheadmod.entity.TestEntity;
import net.mcreator.juliamoorheadmod.entity.Soulfirecharge2Entity;
import net.mcreator.juliamoorheadmod.entity.EpiccopEntity;
import net.mcreator.juliamoorheadmod.entity.Entity4646Entity;
import net.mcreator.juliamoorheadmod.JuliaMoorheadModMod;

@EventBusSubscriber(bus = EventBusSubscriber.Bus.MOD)
public class JuliaMoorheadModModEntities {
	public static final DeferredRegister<EntityType<?>> REGISTRY = DeferredRegister.create(Registries.ENTITY_TYPE, JuliaMoorheadModMod.MODID);
	public static final DeferredHolder<EntityType<?>, EntityType<TestEntity>> TEST = register("test",
			EntityType.Builder.<TestEntity>of(TestEntity::new, MobCategory.MONSTER).setShouldReceiveVelocityUpdates(true).setTrackingRange(64).setUpdateInterval(3).fireImmune().sized(4f, 7f));
	public static final DeferredHolder<EntityType<?>, EntityType<TestEntityProjectile>> TEST_PROJECTILE = register("projectile_test",
			EntityType.Builder.<TestEntityProjectile>of(TestEntityProjectile::new, MobCategory.MISC).setShouldReceiveVelocityUpdates(true).setTrackingRange(64).setUpdateInterval(1).sized(0.5f, 0.5f));
	public static final DeferredHolder<EntityType<?>, EntityType<Soulfirecharge2Entity>> SOULFIRECHARGE_2 = register("soulfirecharge_2",
			EntityType.Builder.<Soulfirecharge2Entity>of(Soulfirecharge2Entity::new, MobCategory.MISC).setShouldReceiveVelocityUpdates(true).setTrackingRange(64).setUpdateInterval(1).sized(0.5f, 0.5f));
	public static final DeferredHolder<EntityType<?>, EntityType<Entity4646Entity>> ENTITY_4646 = register("entity_4646",
			EntityType.Builder.<Entity4646Entity>of(Entity4646Entity::new, MobCategory.MONSTER).setShouldReceiveVelocityUpdates(true).setTrackingRange(64).setUpdateInterval(3).fireImmune().sized(0.6f, 1.8f));
	public static final DeferredHolder<EntityType<?>, EntityType<EpiccopEntity>> EPICCOP = register("epiccop",
			EntityType.Builder.<EpiccopEntity>of(EpiccopEntity::new, MobCategory.MONSTER).setShouldReceiveVelocityUpdates(true).setTrackingRange(64).setUpdateInterval(3).fireImmune().sized(0.6f, 1.8f));

	private static <T extends Entity> DeferredHolder<EntityType<?>, EntityType<T>> register(String registryname, EntityType.Builder<T> entityTypeBuilder) {
		return REGISTRY.register(registryname, () -> (EntityType<T>) entityTypeBuilder.build(registryname));
	}

	@SubscribeEvent
	public static void init(SpawnPlacementRegisterEvent event) {
		TestEntity.init(event);
		Entity4646Entity.init(event);
		EpiccopEntity.init(event);
	}

	@SubscribeEvent
	public static void registerAttributes(EntityAttributeCreationEvent event) {
		event.put(TEST.get(), TestEntity.createAttributes().build());
		event.put(ENTITY_4646.get(), Entity4646Entity.createAttributes().build());
		event.put(EPICCOP.get(), EpiccopEntity.createAttributes().build());
	}
}
