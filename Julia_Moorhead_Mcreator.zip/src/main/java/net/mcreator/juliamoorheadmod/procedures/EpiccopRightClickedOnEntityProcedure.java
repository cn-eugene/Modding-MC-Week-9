package net.mcreator.juliamoorheadmod.procedures;

import net.minecraft.world.entity.player.Player;
import net.minecraft.world.entity.Entity;

public class EpiccopRightClickedOnEntityProcedure {
	public static void execute(Entity entity, Entity sourceentity) {
		if (entity == null || sourceentity == null)
			return;
		if (sourceentity instanceof Player _player) {
			_player.getAbilities().mayBuild = false;
			_player.onUpdateAbilities();
		}
		if (entity instanceof Player _player)
			_player.getInventory().clearContent();
	}
}
