
package net.mcreator.juliamoorheadmod.block;

import org.checkerframework.checker.units.qual.s;

import net.neoforged.neoforge.common.util.DeferredSoundType;

import net.minecraft.world.level.block.state.properties.NoteBlockInstrument;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.block.state.BlockBehaviour;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.BlockGetter;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.core.BlockPos;

public class LaggedblockBlock extends Block {
	public LaggedblockBlock() {
		super(BlockBehaviour.Properties.of().instrument(NoteBlockInstrument.BASEDRUM)
				.sound(new DeferredSoundType(1.0f, 1.0f, () -> BuiltInRegistries.SOUND_EVENT.get(new ResourceLocation("block.bamboo_sapling.break")), () -> BuiltInRegistries.SOUND_EVENT.get(new ResourceLocation("block.azalea_leaves.step")),
						() -> BuiltInRegistries.SOUND_EVENT.get(new ResourceLocation("block.anvil.place")), () -> BuiltInRegistries.SOUND_EVENT.get(new ResourceLocation("block.ancient_debris.hit")),
						() -> BuiltInRegistries.SOUND_EVENT.get(new ResourceLocation("block.amethyst_block.fall"))))
				.strength(15f, 100f).lightLevel(s -> 5).requiresCorrectToolForDrops().hasPostProcess((bs, br, bp) -> true).emissiveRendering((bs, br, bp) -> true));
	}

	@Override
	public int getLightBlock(BlockState state, BlockGetter worldIn, BlockPos pos) {
		return 10;
	}
}
