
package net.mcreator.matthewmoorheadmod.item;

import net.minecraft.world.item.crafting.Ingredient;
import net.minecraft.world.item.Tier;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.AxeItem;

public class AxeoflegendItem extends AxeItem {
	public AxeoflegendItem() {
		super(new Tier() {
			public int getUses() {
				return 542;
			}

			public float getSpeed() {
				return 119.5f;
			}

			public float getAttackDamageBonus() {
				return 45.7f;
			}

			public int getLevel() {
				return 0;
			}

			public int getEnchantmentValue() {
				return 20;
			}

			public Ingredient getRepairIngredient() {
				return Ingredient.of();
			}
		}, 1, -3f, new Item.Properties());
	}
}
