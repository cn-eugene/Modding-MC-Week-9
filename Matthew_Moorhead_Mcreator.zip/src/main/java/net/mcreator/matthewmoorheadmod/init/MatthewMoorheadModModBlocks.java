
/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.matthewmoorheadmod.init;

import net.minecraftforge.registries.RegistryObject;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.DeferredRegister;

import net.minecraft.world.level.block.Block;

import net.mcreator.matthewmoorheadmod.block.WxcBlock;
import net.mcreator.matthewmoorheadmod.block.THECRAZYFISHBlock;
import net.mcreator.matthewmoorheadmod.block.SdfghnbBlock;
import net.mcreator.matthewmoorheadmod.block.EndCrazyEditionPortalBlock;
import net.mcreator.matthewmoorheadmod.block.CANDYOREBlock;
import net.mcreator.matthewmoorheadmod.MatthewMoorheadModMod;

public class MatthewMoorheadModModBlocks {
	public static final DeferredRegister<Block> REGISTRY = DeferredRegister.create(ForgeRegistries.BLOCKS, MatthewMoorheadModMod.MODID);
	public static final RegistryObject<Block> THECRAZYFISH = REGISTRY.register("thecrazyfish", () -> new THECRAZYFISHBlock());
	public static final RegistryObject<Block> CANDYORE = REGISTRY.register("candyore", () -> new CANDYOREBlock());
	public static final RegistryObject<Block> SDFGHNB = REGISTRY.register("sdfghnb", () -> new SdfghnbBlock());
	public static final RegistryObject<Block> WXC = REGISTRY.register("wxc", () -> new WxcBlock());
	public static final RegistryObject<Block> END_CRAZY_EDITION_PORTAL = REGISTRY.register("end_crazy_edition_portal", () -> new EndCrazyEditionPortalBlock());
	// Start of user code block custom blocks
	// End of user code block custom blocks
}
