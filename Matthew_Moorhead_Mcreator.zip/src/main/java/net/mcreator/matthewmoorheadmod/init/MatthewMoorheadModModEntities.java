
/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.matthewmoorheadmod.init;

import net.minecraftforge.registries.RegistryObject;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.fml.event.lifecycle.FMLCommonSetupEvent;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.event.entity.EntityAttributeCreationEvent;

import net.minecraft.world.entity.MobCategory;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.Entity;

import net.mcreator.matthewmoorheadmod.entity.TestEntity;
import net.mcreator.matthewmoorheadmod.entity.Entity909Entity;
import net.mcreator.matthewmoorheadmod.entity.DfgEntity;
import net.mcreator.matthewmoorheadmod.entity.DDDDDDDDDFFFFFFFFFFFFFFFFFFFFEntity;
import net.mcreator.matthewmoorheadmod.MatthewMoorheadModMod;

@Mod.EventBusSubscriber(bus = Mod.EventBusSubscriber.Bus.MOD)
public class MatthewMoorheadModModEntities {
	public static final DeferredRegister<EntityType<?>> REGISTRY = DeferredRegister.create(ForgeRegistries.ENTITY_TYPES, MatthewMoorheadModMod.MODID);
	public static final RegistryObject<EntityType<TestEntity>> TEST = register("test",
			EntityType.Builder.<TestEntity>of(TestEntity::new, MobCategory.MONSTER).setShouldReceiveVelocityUpdates(true).setTrackingRange(64).setUpdateInterval(3).setCustomClientFactory(TestEntity::new).fireImmune().sized(0.6f, 1.95f));
	public static final RegistryObject<EntityType<DfgEntity>> DFG = register("dfg",
			EntityType.Builder.<DfgEntity>of(DfgEntity::new, MobCategory.MISC).setCustomClientFactory(DfgEntity::new).setShouldReceiveVelocityUpdates(true).setTrackingRange(64).setUpdateInterval(1).sized(0.5f, 0.5f));
	public static final RegistryObject<EntityType<Entity909Entity>> ENTITY_909 = register("entity_909",
			EntityType.Builder.<Entity909Entity>of(Entity909Entity::new, MobCategory.MONSTER).setShouldReceiveVelocityUpdates(true).setTrackingRange(64).setUpdateInterval(3).setCustomClientFactory(Entity909Entity::new)

					.sized(0.6f, 1.8f));
	public static final RegistryObject<EntityType<DDDDDDDDDFFFFFFFFFFFFFFFFFFFFEntity>> DDDDDDDDDFFFFFFFFFFFFFFFFFFFF = register("dddddddddffffffffffffffffffff",
			EntityType.Builder.<DDDDDDDDDFFFFFFFFFFFFFFFFFFFFEntity>of(DDDDDDDDDFFFFFFFFFFFFFFFFFFFFEntity::new, MobCategory.MONSTER).setShouldReceiveVelocityUpdates(true).setTrackingRange(64).setUpdateInterval(3)
					.setCustomClientFactory(DDDDDDDDDFFFFFFFFFFFFFFFFFFFFEntity::new)

					.sized(0.4f, 0.3f));

	private static <T extends Entity> RegistryObject<EntityType<T>> register(String registryname, EntityType.Builder<T> entityTypeBuilder) {
		return REGISTRY.register(registryname, () -> (EntityType<T>) entityTypeBuilder.build(registryname));
	}

	@SubscribeEvent
	public static void init(FMLCommonSetupEvent event) {
		event.enqueueWork(() -> {
			TestEntity.init();
			Entity909Entity.init();
			DDDDDDDDDFFFFFFFFFFFFFFFFFFFFEntity.init();
		});
	}

	@SubscribeEvent
	public static void registerAttributes(EntityAttributeCreationEvent event) {
		event.put(TEST.get(), TestEntity.createAttributes().build());
		event.put(ENTITY_909.get(), Entity909Entity.createAttributes().build());
		event.put(DDDDDDDDDFFFFFFFFFFFFFFFFFFFF.get(), DDDDDDDDDFFFFFFFFFFFFFFFFFFFFEntity.createAttributes().build());
	}
}
