
/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.matthewmoorheadmod.init;

import net.minecraftforge.registries.RegistryObject;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.common.ForgeSpawnEggItem;

import net.minecraft.world.level.block.Block;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.BlockItem;

import net.mcreator.matthewmoorheadmod.item.SwordofLegendItem;
import net.mcreator.matthewmoorheadmod.item.SfgItem;
import net.mcreator.matthewmoorheadmod.item.SdfItem;
import net.mcreator.matthewmoorheadmod.item.IngotoflegendItem;
import net.mcreator.matthewmoorheadmod.item.EndCrazyEditionItem;
import net.mcreator.matthewmoorheadmod.item.Bow2Item;
import net.mcreator.matthewmoorheadmod.item.AxeoflegendItem;
import net.mcreator.matthewmoorheadmod.item.ArmorofLegendItem;
import net.mcreator.matthewmoorheadmod.MatthewMoorheadModMod;

public class MatthewMoorheadModModItems {
	public static final DeferredRegister<Item> REGISTRY = DeferredRegister.create(ForgeRegistries.ITEMS, MatthewMoorheadModMod.MODID);
	public static final RegistryObject<Item> THECRAZYFISH = block(MatthewMoorheadModModBlocks.THECRAZYFISH);
	public static final RegistryObject<Item> CANDYORE = block(MatthewMoorheadModModBlocks.CANDYORE);
	public static final RegistryObject<Item> INGOTOFLEGEND = REGISTRY.register("ingotoflegend", () -> new IngotoflegendItem());
	public static final RegistryObject<Item> SWORDOF_LEGEND = REGISTRY.register("swordof_legend", () -> new SwordofLegendItem());
	public static final RegistryObject<Item> AXEOFLEGEND = REGISTRY.register("axeoflegend", () -> new AxeoflegendItem());
	public static final RegistryObject<Item> SFG_HELMET = REGISTRY.register("sfg_helmet", () -> new SfgItem.Helmet());
	public static final RegistryObject<Item> SFG_CHESTPLATE = REGISTRY.register("sfg_chestplate", () -> new SfgItem.Chestplate());
	public static final RegistryObject<Item> SFG_LEGGINGS = REGISTRY.register("sfg_leggings", () -> new SfgItem.Leggings());
	public static final RegistryObject<Item> SFG_BOOTS = REGISTRY.register("sfg_boots", () -> new SfgItem.Boots());
	public static final RegistryObject<Item> ARMOROF_LEGEND_HELMET = REGISTRY.register("armorof_legend_helmet", () -> new ArmorofLegendItem.Helmet());
	public static final RegistryObject<Item> ARMOROF_LEGEND_CHESTPLATE = REGISTRY.register("armorof_legend_chestplate", () -> new ArmorofLegendItem.Chestplate());
	public static final RegistryObject<Item> ARMOROF_LEGEND_LEGGINGS = REGISTRY.register("armorof_legend_leggings", () -> new ArmorofLegendItem.Leggings());
	public static final RegistryObject<Item> ARMOROF_LEGEND_BOOTS = REGISTRY.register("armorof_legend_boots", () -> new ArmorofLegendItem.Boots());
	public static final RegistryObject<Item> SDFGHNB = block(MatthewMoorheadModModBlocks.SDFGHNB);
	public static final RegistryObject<Item> TEST_SPAWN_EGG = REGISTRY.register("test_spawn_egg", () -> new ForgeSpawnEggItem(MatthewMoorheadModModEntities.TEST, -52378, -13421569, new Item.Properties()));
	public static final RegistryObject<Item> WXC = block(MatthewMoorheadModModBlocks.WXC);
	public static final RegistryObject<Item> SDF = REGISTRY.register("sdf", () -> new SdfItem());
	public static final RegistryObject<Item> BOW_2 = REGISTRY.register("bow_2", () -> new Bow2Item());
	public static final RegistryObject<Item> ENTITY_909_SPAWN_EGG = REGISTRY.register("entity_909_spawn_egg", () -> new ForgeSpawnEggItem(MatthewMoorheadModModEntities.ENTITY_909, -10027162, -16763905, new Item.Properties()));
	public static final RegistryObject<Item> END_CRAZY_EDITION = REGISTRY.register("end_crazy_edition", () -> new EndCrazyEditionItem());
	public static final RegistryObject<Item> DDDDDDDDDFFFFFFFFFFFFFFFFFFFF_SPAWN_EGG = REGISTRY.register("dddddddddffffffffffffffffffff_spawn_egg",
			() -> new ForgeSpawnEggItem(MatthewMoorheadModModEntities.DDDDDDDDDFFFFFFFFFFFFFFFFFFFF, -205, -16763905, new Item.Properties()));

	// Start of user code block custom items
	// End of user code block custom items
	private static RegistryObject<Item> block(RegistryObject<Block> block) {
		return REGISTRY.register(block.getId().getPath(), () -> new BlockItem(block.get(), new Item.Properties()));
	}
}
