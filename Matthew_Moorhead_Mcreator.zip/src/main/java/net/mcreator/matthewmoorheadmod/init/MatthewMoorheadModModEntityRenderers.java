
/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.matthewmoorheadmod.init;

import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.client.event.EntityRenderersEvent;
import net.minecraftforge.api.distmarker.Dist;

import net.minecraft.client.renderer.entity.ThrownItemRenderer;

import net.mcreator.matthewmoorheadmod.client.renderer.TestRenderer;
import net.mcreator.matthewmoorheadmod.client.renderer.Entity909Renderer;
import net.mcreator.matthewmoorheadmod.client.renderer.DDDDDDDDDFFFFFFFFFFFFFFFFFFFFRenderer;

@Mod.EventBusSubscriber(bus = Mod.EventBusSubscriber.Bus.MOD, value = Dist.CLIENT)
public class MatthewMoorheadModModEntityRenderers {
	@SubscribeEvent
	public static void registerEntityRenderers(EntityRenderersEvent.RegisterRenderers event) {
		event.registerEntityRenderer(MatthewMoorheadModModEntities.TEST.get(), TestRenderer::new);
		event.registerEntityRenderer(MatthewMoorheadModModEntities.DFG.get(), ThrownItemRenderer::new);
		event.registerEntityRenderer(MatthewMoorheadModModEntities.ENTITY_909.get(), Entity909Renderer::new);
		event.registerEntityRenderer(MatthewMoorheadModModEntities.DDDDDDDDDFFFFFFFFFFFFFFFFFFFF.get(), DDDDDDDDDFFFFFFFFFFFFFFFFFFFFRenderer::new);
	}
}
