
package net.mcreator.matthewmoorheadmod.client.renderer;

import net.minecraft.resources.ResourceLocation;
import net.minecraft.client.renderer.entity.MobRenderer;
import net.minecraft.client.renderer.entity.EntityRendererProvider;
import net.minecraft.client.model.geom.ModelLayers;
import net.minecraft.client.model.VillagerModel;

import net.mcreator.matthewmoorheadmod.entity.TestEntity;

import com.mojang.blaze3d.vertex.PoseStack;

public class TestRenderer extends MobRenderer<TestEntity, VillagerModel<TestEntity>> {
	public TestRenderer(EntityRendererProvider.Context context) {
		super(context, new VillagerModel(context.bakeLayer(ModelLayers.VILLAGER)), 0.5f);
	}

	@Override
	protected void scale(TestEntity entity, PoseStack poseStack, float f) {
		poseStack.scale(0.9375f, 0.9375f, 0.9375f);
	}

	@Override
	public ResourceLocation getTextureLocation(TestEntity entity) {
		return new ResourceLocation("matthew_moorhead_mod:textures/entities/villager_1.png");
	}
}
