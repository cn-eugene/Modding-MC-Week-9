
package net.mcreator.emeraldmaymod.item;

import net.minecraft.world.item.ShieldItem;
import net.minecraft.world.item.Item;

public class RubyShieldItem extends ShieldItem {
	public RubyShieldItem() {
		super(new Item.Properties().durability(100));
	}
}
