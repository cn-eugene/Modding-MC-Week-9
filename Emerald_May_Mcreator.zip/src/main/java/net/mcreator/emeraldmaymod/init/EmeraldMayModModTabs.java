
/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.emeraldmaymod.init;

import net.minecraftforge.registries.RegistryObject;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.event.BuildCreativeModeTabContentsEvent;

import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.CreativeModeTabs;
import net.minecraft.world.item.CreativeModeTab;
import net.minecraft.network.chat.Component;
import net.minecraft.core.registries.Registries;

import net.mcreator.emeraldmaymod.EmeraldMayModMod;

@Mod.EventBusSubscriber(bus = Mod.EventBusSubscriber.Bus.MOD)
public class EmeraldMayModModTabs {
	public static final DeferredRegister<CreativeModeTab> REGISTRY = DeferredRegister.create(Registries.CREATIVE_MODE_TAB, EmeraldMayModMod.MODID);
	public static final RegistryObject<CreativeModeTab> OP_ITEMS = REGISTRY.register("op_items",
			() -> CreativeModeTab.builder().title(Component.translatable("item_group.emerald_may_mod.op_items")).icon(() -> new ItemStack(EmeraldMayModModItems.RUBY_SWORD.get())).displayItems((parameters, tabData) -> {
				tabData.accept(EmeraldMayModModBlocks.RUBYBLOCK_3.get().asItem());
				tabData.accept(EmeraldMayModModItems.RUBY_SWORD.get());
				tabData.accept(EmeraldMayModModItems.RUBY_APPLE.get());
				tabData.accept(EmeraldMayModModItems.RUBY_AXE.get());
				tabData.accept(EmeraldMayModModItems.RUBY_ARMOUR_HELMET.get());
				tabData.accept(EmeraldMayModModItems.RUBY_ARMOUR_CHESTPLATE.get());
				tabData.accept(EmeraldMayModModItems.RUBY_ARMOUR_LEGGINGS.get());
				tabData.accept(EmeraldMayModModItems.RUBY_ARMOUR_BOOTS.get());
				tabData.accept(EmeraldMayModModItems.TNT_STICK.get());
			})

					.build());

	@SubscribeEvent
	public static void buildTabContentsVanilla(BuildCreativeModeTabContentsEvent tabData) {
		if (tabData.getTabKey() == CreativeModeTabs.COMBAT) {
			tabData.accept(EmeraldMayModModItems.RUBY_SWORD.get());
			tabData.accept(EmeraldMayModModItems.RUBY_ARMOUR_HELMET.get());
			tabData.accept(EmeraldMayModModItems.RUBY_ARMOUR_CHESTPLATE.get());
			tabData.accept(EmeraldMayModModItems.RUBY_ARMOUR_LEGGINGS.get());
			tabData.accept(EmeraldMayModModItems.RUBY_ARMOUR_BOOTS.get());
		} else if (tabData.getTabKey() == CreativeModeTabs.SPAWN_EGGS) {
			tabData.accept(EmeraldMayModModItems.PETCREEPER_SPAWN_EGG.get());
			tabData.accept(EmeraldMayModModItems.ENTITY_555_SPAWN_EGG.get());
		} else if (tabData.getTabKey() == CreativeModeTabs.INGREDIENTS) {
			tabData.accept(EmeraldMayModModItems.RUBYGEM.get());
		} else if (tabData.getTabKey() == CreativeModeTabs.NATURAL_BLOCKS) {
			tabData.accept(EmeraldMayModModBlocks.RUBY.get().asItem());
		} else if (tabData.getTabKey() == CreativeModeTabs.FOOD_AND_DRINKS) {
			tabData.accept(EmeraldMayModModItems.RUBY_APPLE.get());
		} else if (tabData.getTabKey() == CreativeModeTabs.TOOLS_AND_UTILITIES) {
			tabData.accept(EmeraldMayModModItems.RUBY_SHIELD.get());
			tabData.accept(EmeraldMayModModItems.RUBY_AXE.get());
		}
	}
}
