
/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.emeraldmaymod.init;

import net.minecraftforge.registries.RegistryObject;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.fml.event.lifecycle.FMLClientSetupEvent;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.common.ForgeSpawnEggItem;
import net.minecraftforge.api.distmarker.Dist;

import net.minecraft.world.level.block.Block;
import net.minecraft.world.item.Items;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.BlockItem;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.client.renderer.item.ItemProperties;

import net.mcreator.emeraldmaymod.item.TNTStickItem;
import net.mcreator.emeraldmaymod.item.RubygemItem;
import net.mcreator.emeraldmaymod.item.RubySwordItem;
import net.mcreator.emeraldmaymod.item.RubyShieldItem;
import net.mcreator.emeraldmaymod.item.RubyAxeItem;
import net.mcreator.emeraldmaymod.item.RubyArmourItem;
import net.mcreator.emeraldmaymod.item.RubyAppleItem;
import net.mcreator.emeraldmaymod.item.FireballItem;
import net.mcreator.emeraldmaymod.EmeraldMayModMod;

@Mod.EventBusSubscriber(bus = Mod.EventBusSubscriber.Bus.MOD, value = Dist.CLIENT)
public class EmeraldMayModModItems {
	public static final DeferredRegister<Item> REGISTRY = DeferredRegister.create(ForgeRegistries.ITEMS, EmeraldMayModMod.MODID);
	public static final RegistryObject<Item> RUBYGEM = REGISTRY.register("rubygem", () -> new RubygemItem());
	public static final RegistryObject<Item> RUBY = block(EmeraldMayModModBlocks.RUBY);
	public static final RegistryObject<Item> RUBYBLOCK_3 = block(EmeraldMayModModBlocks.RUBYBLOCK_3);
	public static final RegistryObject<Item> RUBY_SWORD = REGISTRY.register("ruby_sword", () -> new RubySwordItem());
	public static final RegistryObject<Item> RUBY_APPLE = REGISTRY.register("ruby_apple", () -> new RubyAppleItem());
	public static final RegistryObject<Item> RUBY_SHIELD = REGISTRY.register("ruby_shield", () -> new RubyShieldItem());
	public static final RegistryObject<Item> RUBY_AXE = REGISTRY.register("ruby_axe", () -> new RubyAxeItem());
	public static final RegistryObject<Item> RUBY_ARMOUR_HELMET = REGISTRY.register("ruby_armour_helmet", () -> new RubyArmourItem.Helmet());
	public static final RegistryObject<Item> RUBY_ARMOUR_CHESTPLATE = REGISTRY.register("ruby_armour_chestplate", () -> new RubyArmourItem.Chestplate());
	public static final RegistryObject<Item> RUBY_ARMOUR_LEGGINGS = REGISTRY.register("ruby_armour_leggings", () -> new RubyArmourItem.Leggings());
	public static final RegistryObject<Item> RUBY_ARMOUR_BOOTS = REGISTRY.register("ruby_armour_boots", () -> new RubyArmourItem.Boots());
	public static final RegistryObject<Item> PETCREEPER_SPAWN_EGG = REGISTRY.register("petcreeper_spawn_egg", () -> new ForgeSpawnEggItem(EmeraldMayModModEntities.PETCREEPER, -13369600, -65536, new Item.Properties()));
	public static final RegistryObject<Item> FIREBALL = REGISTRY.register("fireball", () -> new FireballItem());
	public static final RegistryObject<Item> ENTITY_555_SPAWN_EGG = REGISTRY.register("entity_555_spawn_egg", () -> new ForgeSpawnEggItem(EmeraldMayModModEntities.ENTITY_555, -16777114, -65536, new Item.Properties()));
	public static final RegistryObject<Item> TNT_STICK = REGISTRY.register("tnt_stick", () -> new TNTStickItem());

	// Start of user code block custom items
	// End of user code block custom items
	private static RegistryObject<Item> block(RegistryObject<Block> block) {
		return REGISTRY.register(block.getId().getPath(), () -> new BlockItem(block.get(), new Item.Properties()));
	}

	@SubscribeEvent
	public static void clientLoad(FMLClientSetupEvent event) {
		event.enqueueWork(() -> {
			ItemProperties.register(RUBY_SHIELD.get(), new ResourceLocation("blocking"), ItemProperties.getProperty(Items.SHIELD, new ResourceLocation("blocking")));
		});
	}
}
