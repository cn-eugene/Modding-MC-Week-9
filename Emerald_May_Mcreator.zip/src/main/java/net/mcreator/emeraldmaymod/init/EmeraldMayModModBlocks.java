
/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.emeraldmaymod.init;

import net.minecraftforge.registries.RegistryObject;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.DeferredRegister;

import net.minecraft.world.level.block.Block;

import net.mcreator.emeraldmaymod.block.Rubyblock3Block;
import net.mcreator.emeraldmaymod.block.RubyBlock;
import net.mcreator.emeraldmaymod.EmeraldMayModMod;

public class EmeraldMayModModBlocks {
	public static final DeferredRegister<Block> REGISTRY = DeferredRegister.create(ForgeRegistries.BLOCKS, EmeraldMayModMod.MODID);
	public static final RegistryObject<Block> RUBY = REGISTRY.register("ruby", () -> new RubyBlock());
	public static final RegistryObject<Block> RUBYBLOCK_3 = REGISTRY.register("rubyblock_3", () -> new Rubyblock3Block());
	// Start of user code block custom blocks
	// End of user code block custom blocks
}
