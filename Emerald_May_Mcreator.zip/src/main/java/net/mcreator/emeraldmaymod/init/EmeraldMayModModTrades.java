
/*
*	MCreator note: This file will be REGENERATED on each build.
*/
package net.mcreator.emeraldmaymod.init;

import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.event.village.VillagerTradesEvent;
import net.minecraftforge.common.BasicItemListing;

import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.item.Items;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.entity.npc.VillagerProfession;

@Mod.EventBusSubscriber(bus = Mod.EventBusSubscriber.Bus.FORGE)
public class EmeraldMayModModTrades {
	@SubscribeEvent
	public static void registerTrades(VillagerTradesEvent event) {
		if (event.getType() == VillagerProfession.CLERIC) {
			event.getTrades().get(5).add(new BasicItemListing(new ItemStack(Items.EMERALD, 64),

					new ItemStack(EmeraldMayModModItems.RUBYGEM.get()), 20, 5, 0.05f));
		}
		if (event.getType() == EmeraldMayModModVillagerProfessions.ILLEGAL.get()) {
			event.getTrades().get(3).add(new BasicItemListing(new ItemStack(Items.EMERALD, 64),

					new ItemStack(Blocks.BARRIER), 10, 30, 0.05f));
		}
	}
}
