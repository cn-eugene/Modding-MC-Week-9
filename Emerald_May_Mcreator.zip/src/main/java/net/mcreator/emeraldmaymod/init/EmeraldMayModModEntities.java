
/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.emeraldmaymod.init;

import net.minecraftforge.registries.RegistryObject;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.fml.event.lifecycle.FMLCommonSetupEvent;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.event.entity.EntityAttributeCreationEvent;

import net.minecraft.world.entity.MobCategory;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.Entity;

import net.mcreator.emeraldmaymod.entity.PetcreeperEntity;
import net.mcreator.emeraldmaymod.entity.KaboomEntity;
import net.mcreator.emeraldmaymod.entity.Fireball1Entity;
import net.mcreator.emeraldmaymod.entity.Entity555Entity;
import net.mcreator.emeraldmaymod.EmeraldMayModMod;

@Mod.EventBusSubscriber(bus = Mod.EventBusSubscriber.Bus.MOD)
public class EmeraldMayModModEntities {
	public static final DeferredRegister<EntityType<?>> REGISTRY = DeferredRegister.create(ForgeRegistries.ENTITY_TYPES, EmeraldMayModMod.MODID);
	public static final RegistryObject<EntityType<PetcreeperEntity>> PETCREEPER = register("petcreeper", EntityType.Builder.<PetcreeperEntity>of(PetcreeperEntity::new, MobCategory.MONSTER).setShouldReceiveVelocityUpdates(true).setTrackingRange(64)
			.setUpdateInterval(3).setCustomClientFactory(PetcreeperEntity::new).fireImmune().sized(0.6f, 1.7f));
	public static final RegistryObject<EntityType<Fireball1Entity>> FIREBALL_1 = register("fireball_1",
			EntityType.Builder.<Fireball1Entity>of(Fireball1Entity::new, MobCategory.MISC).setCustomClientFactory(Fireball1Entity::new).setShouldReceiveVelocityUpdates(true).setTrackingRange(64).setUpdateInterval(1).sized(0.5f, 0.5f));
	public static final RegistryObject<EntityType<Entity555Entity>> ENTITY_555 = register("entity_555",
			EntityType.Builder.<Entity555Entity>of(Entity555Entity::new, MobCategory.MONSTER).setShouldReceiveVelocityUpdates(true).setTrackingRange(1).setUpdateInterval(3).setCustomClientFactory(Entity555Entity::new).fireImmune().sized(0.6f, 1.8f));
	public static final RegistryObject<EntityType<KaboomEntity>> KABOOM = register("kaboom",
			EntityType.Builder.<KaboomEntity>of(KaboomEntity::new, MobCategory.MISC).setCustomClientFactory(KaboomEntity::new).setShouldReceiveVelocityUpdates(true).setTrackingRange(64).setUpdateInterval(1).sized(0.5f, 0.5f));

	private static <T extends Entity> RegistryObject<EntityType<T>> register(String registryname, EntityType.Builder<T> entityTypeBuilder) {
		return REGISTRY.register(registryname, () -> (EntityType<T>) entityTypeBuilder.build(registryname));
	}

	@SubscribeEvent
	public static void init(FMLCommonSetupEvent event) {
		event.enqueueWork(() -> {
			PetcreeperEntity.init();
			Entity555Entity.init();
		});
	}

	@SubscribeEvent
	public static void registerAttributes(EntityAttributeCreationEvent event) {
		event.put(PETCREEPER.get(), PetcreeperEntity.createAttributes().build());
		event.put(ENTITY_555.get(), Entity555Entity.createAttributes().build());
	}
}
